#ifndef FLAPPY_BIRD_H
#define FLAPPY_BIRD_H
#include "LedControl.h"
#include "pitches.h"
#include  "Wire.h"


/*led pin               din clk cs*/
LedControl lc=LedControl(13, 7, 8,1);
#define BRIGHT 2                      //you can change the Intensity of max7219

/*buzzer pin*/
const uint8_t BUZZER=4;
/*about the music*/
int16_t duration = 30;  // 500 miliseconds
int melody[8] = {NOTE_C5, NOTE_D5, NOTE_E5, NOTE_F5, NOTE_G5, NOTE_A5, NOTE_B5, NOTE_C6};
int melody_start[8] = {NOTE_B5, NOTE_D5, NOTE_B5, NOTE_F5, NOTE_B5, NOTE_A5, NOTE_B5, NOTE_B5};
int melody_fail[8] = {NOTE_E4, NOTE_G4, NOTE_B4, NOTE_A4, NOTE_G4, NOTE_E4, NOTE_G4, NOTE_A4};
volatile static uint8_t win_note=0;
volatile static uint8_t start_note=0;
volatile static uint8_t fail_note=0;

/*button pin*/
#define BUTTON_1 A3
#define ELIMINAT_THE_JITTER_OF_BUTTON_1 (200 < (abs(time_button_1 - last_time_button_1))) //Elimination Buffeting of Keystroke
/*Record the interval between keystrokes*/
volatile static int time_button_1=0;     
volatile static int last_time_button_1=0;

/*obstacle*/
enum obstacle_type
{
  OBSTACLE_1=0xf0,
  OBSTACLE_2=0x0f,
  OBSTACLE_3=0xe1,
  OBSTACLE_4=0x87,
  OBSTACLE_5=0xc3
};
int obstacle_shape[5]={OBSTACLE_1,OBSTACLE_2,OBSTACLE_3,OBSTACLE_4,OBSTACLE_5};
int get_obstacle[8]={0};
//Divide the occurrence of successive obstacles into two parts
int part1 = 1, part2 = 7 ;

/*Bird position*/
int bird_row=4;
int bird_col=3;


//flag
volatile static uint8_t timer_interrupt_flag=0;
volatile static uint8_t start_interface_flag=1;
volatile static uint8_t end_interface_flag=0;
volatile static uint8_t win_voice_flag=0;
volatile static uint8_t start_voice_flag=0;
volatile static uint8_t fail_voice_flag=0;
volatile static uint8_t obstacle_movement_display_flag=1;
volatile static uint8_t if_hit_obstacle_flag=1;

volatile static uint16_t  task1_cnt=0;
volatile static uint16_t  task2_cnt=0;
volatile static uint16_t  task4_cnt=0;
volatile static uint16_t  task5_cnt=0;
volatile static uint8_t   goal_cnt=0;

#endif
